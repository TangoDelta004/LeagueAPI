const Sequelize = require('sequelize')
module.exports =  new Sequelize('postgres://postgres:leaguepass@localhost:5432/LeagueAPP') // Example for postgres
